<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="css/item.css">
    <title>Document</title>
</head>
<body style="font-family: 'Gill Sans MT'">

<?php $__env->startSection('content'); ?>

<div class="container">
    <?php if(Request::path() == 'search'): ?>
        <?php echo $__env->make('search', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>

    <?php if(auth()->guard()->check()): ?>
        <?php if(auth()->user()->id != 1): ?>
            <div class="container" style="min-height: 71.2vh">
                <div class="place">
                    <div class="row">
                        <?php for($i=0; $i<count($products);$i++): ?>
                            <div class="col sm-4 mb-5">
                                <div class="card" style="width: 20rem;">
                                    <img src="<?php echo e(Storage::url($products[$i]->image)); ?>" class="card-img-top"
                                         style="width: 20rem; height: 14rem" alt="">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($products[$i]->title); ?></h5>
                                        <p class="card-text"><?php echo e($products[$i]->desc); ?></p>
                                        <p class="card-text">Rp. <?php echo e($products[$i]->price); ?></p>
                                        <a href="/details/<?php echo e($products[$i]->id); ?>" class="btn btn-primary">Product Details</a>
                                    </div>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        <?php else: ?>
            <div class="container" style="min-height: 71.2vh">
                <div class="place">
                    <div class="row">
                        <?php for($i=0; $i<count($products);$i++): ?>
                            <div class="col sm-4 mb-5">
                                <div class="card" style="width: 20rem;">
                                    <img src="<?php echo e(Storage::url($products[$i]->image)); ?>" class="card-img-top"
                                         style="width: 20rem; height: 14rem" alt="">
                                    <div class="card-body">
                                        <h5 class="card-title"><?php echo e($products[$i]->title); ?></h5>
                                        <p class="card-text"><?php echo e($products[$i]->desc); ?></p>
                                        <p class="card-text">Rp. <?php echo e($products[$i]->price); ?></p>
                                        <a href="/updateproduct/<?php echo e($products[$i]->id); ?>" class="btn btn-danger">Update Product</a>
                                        <a href="/details/<?php echo e($products[$i]->id); ?>" class="btn btn-primary">Product Details</a>
                                    </div>
                                </div>
                            </div>
                        <?php endfor; ?>
                    </div>
                </div>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="container" style="min-height: 71.2vh">
            <div class="place">
                <div class="row">
                    <?php for($i=0; $i<count($products);$i++): ?>
                        <div class="col sm-4 mb-5">
                            <div class="card" style="width: 20rem;">
                                <img src="<?php echo e(Storage::url($products[$i]->image)); ?>" class="card-img-top"
                                     style="width: 20rem; height: 14rem" alt="">
                                <div class="card-body">
                                    <h5 class="card-title"><?php echo e($products[$i]->title); ?></h5>
                                    <p class="card-text"><?php echo e($products[$i]->desc); ?></p>
                                    <p class="card-text">Rp. <?php echo e($products[$i]->price); ?></p>
                                    <a href="/details/<?php echo e($products[$i]->id); ?>" class="btn btn-primary">Product Details</a>
                                </div>
                            </div>
                        </div>
                    <?php endfor; ?>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <div class="page" style="display: flex; justify-content: center">
        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($products->previousPageUrl()); ?>">Previous</a>
                </li>
                <?php for($i=1;$i<=$products->lastPage();$i++): ?>
                    <?php if($i == $products->currentPage()): ?>
                        <li class="page-item disabled"><a href="#" class="page-link"><?php echo e($i); ?></a></li>
                    <?php else: ?>
                        <li class="page-item"><a href="<?php echo e($products->url($i)); ?>" class="page-link"><?php echo e($i); ?></a></li>
                    <?php endif; ?>
                <?php endfor; ?>
                <li class="page-item">
                    <a class="page-link" href="<?php echo e($products->nextPageUrl()); ?>">Next</a>
                </li>
            </ul>

        </nav>
    </div>
</div>


<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\Applications\ProjectLab\LAB\resources\views/item.blade.php ENDPATH**/ ?>