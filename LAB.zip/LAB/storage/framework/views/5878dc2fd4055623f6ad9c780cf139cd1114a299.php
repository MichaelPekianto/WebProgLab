<!doctype html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/navbar.css')); ?>">
    <title>Document</title>

</head>

<body>
    
    <?php $__env->startSection('content'); ?>
    <div class="container" style="min-height: 71.8vh">
     <h2>Cart</h2>
<table class="table">
    <thead class="thead-dark">
        <tr>
            <th scope="col">No</th>
            <th scope="col">Item Name</th>
            <th scope="col">Item Detail</th>
            <th scope="col">Price</th>
            <th scope="col">Quantity</th>
            <th scope="col">SubTotal</th>
        </tr>
    </thead>
    <tbody>
        <div class="invisible">
            <?php echo e($count=0); ?>

        </div>
        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <th scope="row"><?php echo e($loop->index+1); ?> </th>
            <td><?php echo e($item->getProduct->title); ?></td>
            <td><?php echo e($item->getProduct->desc); ?></td>
            <td><?php echo e($item->getProduct->price); ?></td>
            <td><?php echo e($item->quantity); ?></td>
            <td><?php echo e($item->quantity*$item->getProduct->price); ?></td>
            <div class="invisible">
                <?php echo e($count+=$item->quantity*$item->getProduct->price); ?>

            </div>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
    <p class="text-right">Grand Total: Rp.<?php echo e($count); ?>,-</p>
</div>
<?php $__env->stopSection(); ?>

</body>

</html>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\Applications\ProjectLab\LAB\resources\views/detailtransaction.blade.php ENDPATH**/ ?>