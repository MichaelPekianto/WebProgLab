<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e($products->title); ?></title>
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/item.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body>
<?php echo $__env->make('navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


        <div class="holder" style="display: flex; justify-content: center">
            <div class="img mt-10">
                <img src="<?php echo e(Storage::url($products->image)); ?>" class="rounded" alt="..." style="width: 400px; height: 400px">
            </div>
            <div class="placehold">
                <h1><?php echo e($products->title); ?></h1>
                <h2>Description :</h2>
                <p><?php echo e($products->desc); ?></p>
                <h3>Stock :</h3>
                <p><?php echo e($products->stock); ?></p>
                <h4>Price :</h4>
                <p>Rp. <?php echo e($products->price); ?>,-</p>
            </div>
        </div>
    

<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</body>
</html>
<?php /**PATH D:\Jeco\BERANGKAT\BERANGKAT\Semester 5\Webprog\ProjectLab\LAB\resources\views/details.blade.php ENDPATH**/ ?>