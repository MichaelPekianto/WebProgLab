<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/navbar.css')); ?>">

    <title><?php echo e($products->title); ?></title>
</head>
<body>

<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->check()): ?>
    <?php if(auth()->user()->id != 1): ?>
        <div class="container" style="min-height: 71.2vh">
            <div class="holder" style="display: flex;padding-left: 15%">
                <div class="img mt-10">
                    <img src="<?php echo e(Storage::url($products->image)); ?>" class="rounded" alt="..."
                         style="width: 400px; height: 400px">
                </div>
                <div class="placehold" style="margin-left: 100px">
                    <h1 style="font-family: Bahnschrift; font-size: 60px"><?php echo e($products->title); ?></h1>
                    <h2 style="font-family: 'Gill Sans MT';">Description :</h2>
                    <p style="font-family: 'Gill Sans MT'; font-size: 20px;width: 600px"><?php echo e($products->desc); ?></p>
                    <h3 style="font-family: 'Gill Sans MT';">Stock :</h3>
                    <p style="font-family: 'Gill Sans MT'; font-size: 20px"><?php echo e($products->stock); ?></p>
                    <h4 style="font-family: 'Gill Sans MT';">Price :</h4>
                    <p style="font-family: 'Gill Sans MT'; font-size: 20px">Rp. <?php echo e($products->price); ?>,-</p>
                    <form class="row g-3">
                        <?php echo csrf_field(); ?>
                        <div class="col-auto">
                            <label for="inputQuantity" class="visually-hidden">Quantity</label>
                            <input type="value" class="form-control" id="quantity" name="quantity"
                                   placeholder="Quantity">
                        </div>
                        <div class="col-auto">
                            <button type="submit" class="btn btn-primary mb-3">Add to Cart</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    <?php else: ?>
        <div class="container" style="min-height: 71.2vh">
            <div class="holder" style="display: flex;padding-left: 15%">
                <div class="img mt-10">
                    <img src="<?php echo e(Storage::url($products->image)); ?>" class="rounded" alt="..."
                         style="width: 400px; height: 400px">
                </div>
                <div class="placehold" style="margin-left: 100px">
                    <h1 style="font-family: Bahnschrift; font-size: 60px"><?php echo e($products->title); ?></h1>
                    <h2 style="font-family: 'Gill Sans MT';">Description :</h2>
                    <p style="font-family: 'Gill Sans MT'; font-size: 20px;width: 600px"><?php echo e($products->desc); ?></p>
                    <h3 style="font-family: 'Gill Sans MT';">Stock :</h3>
                    <p style="font-family: 'Gill Sans MT'; font-size: 20px"><?php echo e($products->stock); ?></p>
                    <h4 style="font-family: 'Gill Sans MT';">Price :</h4>
                    <p style="font-family: 'Gill Sans MT'; font-size: 20px">Rp. <?php echo e($products->price); ?>,-</p>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php else: ?>
    <div class="container" style="min-height: 71.2vh">
        <div class="holder" style="display: flex;padding-left: 15%">
            <div class="img mt-10">
                <img src="<?php echo e(Storage::url($products->image)); ?>" class="rounded" alt="..."
                     style="width: 400px; height: 400px">
            </div>
            <div class="placehold" style="margin-left: 100px">
                <h1 style="font-family: Bahnschrift; font-size: 60px"><?php echo e($products->title); ?></h1>
                <h2 style="font-family: 'Gill Sans MT';">Description :</h2>
                <p style="font-family: 'Gill Sans MT'; font-size: 20px;width: 600px"><?php echo e($products->desc); ?></p>
                <h3 style="font-family: 'Gill Sans MT';">Stock :</h3>
                <p style="font-family: 'Gill Sans MT'; font-size: 20px"><?php echo e($products->stock); ?></p>
                <h4 style="font-family: 'Gill Sans MT';">Price :</h4>
                <p style="font-family: 'Gill Sans MT'; font-size: 20px">Rp. <?php echo e($products->price); ?>,-</p>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Jeco\BERANGKAT\BERANGKAT\Semester 5\Webprog\ProjectLab\LAB\resources\views/detail.blade.php ENDPATH**/ ?>