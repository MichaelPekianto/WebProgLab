<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body style="font-family: 'Gill Sans MT'">

<?php $__env->startSection('content'); ?>
    <div class="container" style="min-height: 71.8vh">
        <table class="table">
            <thead>
            <tr>
                <th scope="col" style="width: 10%">User ID</th>
                <th scope="col" style="width: 60%">Username</th>
                <th scope="col" style="width: 30%"></th>
            </tr>
            </thead>
            <tbody>
            <?php for($i=0;$i<count($user);$i++): ?>
                <?php if($user[$i]->id != 1): ?>
                    <tr>
                        <th scope="row"><?php echo e($user[$i]->id); ?></th>
                        <td><?php echo e($user[$i]->name); ?></td>
                        <form action="manageuser/<?php echo e($user[$i]->id); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <td><button class="btn btn-danger" type="submit" onclick="return confirm('Are you sure you want to delete the user <?php echo e($user[$i]->name); ?>?')">Delete</button></td>
                        </form>
                    </tr>
            <?php endif; ?>
            <?php endfor; ?>
        </table>
    </div>

<?php $__env->stopSection(); ?>
</body>
</html>

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Jeco\BERANGKAT\BERANGKAT\Semester 5\Webprog\ProjectLab\LAB\resources\views/manageuser.blade.php ENDPATH**/ ?>